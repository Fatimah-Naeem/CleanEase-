#include <iostream>
#include <vector>
using namespace std;
// FACTORY PATTERN 
// Abstract Class
class Laundry {
public:
    virtual int getPrice() = 0;
    virtual void serviceInfo() = 0;
};
// Wash 
class Wash : public Laundry{
public:
    int getPrice() {
        return 500;
    }
    void serviceInfo() {
        cout << "Wash Service Selected\n";
    }
};
// Iron 
class Iron : public Laundry{
public:
    int getPrice() {
        return 300;
    }
    void serviceInfo() {
        cout << "Iron Service Selected\n";
    }
};
// Dry Clean 
class DryClean : public Laundry{
public:
    int getPrice() {
        return 800;
    }
    void serviceInfo() {
        cout << "Dry Clean Service Selected\n";
    }
};
// Factory 
class ServiceFactory {
public:
    static Laundry* createService(int choice) {
        if(choice == 1)
            return new Wash();
        else if(choice == 2)
            return new Iron();
        else if(choice == 3)
            return new DryClean();
        else
            return NULL;
    }
};
// OBSERVER PATTERN 
// Observer Interface
class Observer {
public:
    virtual void update(string status) = 0;
};
// Customer 
class Customer : public Observer {
private:
    string name;
public:
    Customer(string n) {
        name = n;
    }
    void update(string status) {
        cout << "\nNotification for " << name
             << ": " << status << endl;
    }
};
// Order 
class Order {
private:
    vector<Observer*> observers;
public:
    void addObserver(Observer* obs) {
        observers.push_back(obs);
    }
    void setStatus(string status) {
        for(int i = 0; i < observers.size(); i++) {
            observers[i]->update(status);
        }
    }
};
//  MAIN FUNCTION 
int main() {
    string customerName;
    int choice, quantity;
    cout << "========== CleanEase Laundry System ==========\n";
    // Customer Name
    cout << "\nEnter Customer Name: ";
    cin >> customerName;
    // Service Menu
    cout << "\nSelect Laundry Service:\n";
    cout << "1. Wash (Rs.500)\n";
    cout << "2. Iron (Rs.300)\n";
    cout << "3. Dry Clean (Rs.800)\n";
    cout << "Enter Choice: ";
    cin >> choice;
    // Factory Pattern
    Laundry* service =
        ServiceFactory::createService(choice);
    if(service == NULL) {
        cout << "Invalid Choice\n";
        return 0;
    }
    service->serviceInfo();
    // Quantity
    cout << "\nEnter Number of Clothes: ";
    cin >> quantity;
    int totalBill = service->getPrice() * quantity;
    cout << "\nTotal Bill: Rs." << totalBill << endl;
    // Observer Pattern
    Customer customer(customerName);
    Order order;
    order.addObserver(&customer);
    cout << "\n======= Order Updates =======\n";
    order.setStatus("Order Placed Successfully");
    order.setStatus("Laundry Processing Started");
    order.setStatus("Laundry Completed");
    order.setStatus("Order Ready for Delivery");
    cout << "\nThank you for using CleanEase!\n";
    return 0;
}